let sub = document.getElementById("submit");

sub.addEventListener("click" , () => {
    window.open("../html/loginTeach.html" ,"_self")
})