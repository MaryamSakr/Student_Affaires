let id = document.getElementById("id");
let phone = document.getElementById("phone");
let name = document.getElementById("name");
let address = document.getElementById("address");
let gender = document.getElementById("gender");
let year = document.getElementById("year");
let department = document.getElementById("department");
let studNum = JSON.parse(localStorage.getItem("studNum"));
let del = document.getElementById("delete");

let errorid = document.getElementById("errorId");
let errorPhone = document.getElementById("errorPhone");
let existId = document.getElementById("existId");
let phoneExist = document.getElementById("phoneExist");
let lessDepart = document.getElementById("lessDepart");
let overDepart = document.getElementById("overDepart");

let sub = document.getElementById("submit");
let myForm = document.getElementById("form");
let stud = [];

name.placeholder = JSON.parse(localStorage.getItem("studData"))[
    studNum
].studName;
id.placeholder = JSON.parse(localStorage.getItem("studData"))[
    studNum
].studId;
phone.placeholder = JSON.parse(localStorage.getItem("studData"))[
    studNum
].studPhone;
address.placeholder = JSON.parse(localStorage.getItem("studData"))[
    studNum
].studAddress;
if (JSON.parse(localStorage.getItem("studData"))[
    studNum
].studGender == "Male") {
    gender[1].setAttribute('selected', 'selected')
} else {
    gender[2].setAttribute("selected", "selected");
}
if (JSON.parse(localStorage.getItem("studData"))[studNum].studYear == 1) {
    year[1].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studYear == 2
) {
    year[2].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studYear == 3
) {
    year[3].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studYear == 4
) {
    year[4].setAttribute("selected", "selected");
}


if (JSON.parse(localStorage.getItem("studData"))[studNum].studDepart == "CS") {
    department[1].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studDepart == "IS"
) {
    department[2].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studDepart == "DS"
) {
    department[3].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studDepart == "AI"
) {
    department[4].setAttribute("selected", "selected");
} else if (
    JSON.parse(localStorage.getItem("studData"))[studNum].studDepart == "IT"
) {
    department[5].setAttribute("selected", "selected");
}


id.value = JSON.parse(localStorage.getItem("studData"))[studNum].studId;
name.value = JSON.parse(localStorage.getItem("studData"))[studNum].studName;
phone.value = JSON.parse(localStorage.getItem("studData"))[studNum].studPhone;
address.value = JSON.parse(localStorage.getItem("studData"))[
    studNum
].studAddress;

myForm.addEventListener("click", () => {
    id.addEventListener("blur", () => {
        idValue = id.value;

        if (idValue.length != 8 || isNaN(idValue)) {
            errorid.classList.add("hide");
        } else {
            errorid.classList.remove("hide");
        }
        if (localStorage.getItem("studData") != null) {
            for (
                let i = 0;
                i < JSON.parse(localStorage.getItem("studData")).length;
                i++
            ) {
                if (
                    idValue === JSON.parse(localStorage.getItem("studData"))[i].studId
                ) {
                    existId.classList.add("hide");
                    break;
                } else {
                    existId.classList.remove("hide");
                }
            }
        }
    });

    phone.addEventListener("blur", () => {
        phoneval = phone.value;
        phonereg = /^(01(1|2|5|0)\d*)/g;
        if (!(phoneval.match(phonereg) && phoneval.length == 11)) {
            errorPhone.classList.add("hide");
        } else {
            errorPhone.classList.remove("hide");
        }
        if (localStorage.getItem("studData") != null) {
            for (
                let i = 0;
                i < JSON.parse(localStorage.getItem("studData")).length;
                i++
            ) {
                if (
                    phoneval === JSON.parse(localStorage.getItem("studData"))[i].studPhone
                ) {
                    phoneExist.classList.add("hide");
                    break;
                } else {
                    phoneExist.classList.remove("hide");
                }
            }
        }
    });

    department.addEventListener("blur", () => {
        depValue = department.vlaue;
        if (department.value !== "--Select Department--") {
            overDepart.classList.remove("hide");
            if (year.value != 3 && year.value != 4) {
                lessDepart.classList.add("hide");
            } else {
                lessDepart.classList.remove("hide");
            }
        } else {
            lessDepart.classList.remove("hide");
            if (year.value == 3 && year.value == 4) {
                overDepart.classList.add("hide");
            } else {
                overDepart.classList.remove("hide");
            }
        }
    });

    year.addEventListener("click", () => {
        yearValue = year.value;
        if (year.value == 1 || year.value == 2 || year.value == "--Select Year--") {
            overDepart.classList.remove("hide");
            if (department.value !== "--Select Department--") {
                lessDepart.classList.add("hide");
            } else {
                lessDepart.classList.remove("hide");
            }
        } else {
            lessDepart.classList.remove("hide");
            if (department.value === "--Select Department--") {
                overDepart.classList.add("hide");
            } else {
                overDepart.classList.remove("hide");
            }
        }
    });
});

sub.addEventListener("click", () => {
    let stud2 = [];
    if (
        name.value !== "" &&
        id.value !== "" &&
        phone.value !== "" &&
        address.value !== "" &&
        year.value !== "--Select Year--" &&
        gender.value !== "--Select Gender--" &&
        !errorid.classList.contains("hide") &&
        !errorPhone.classList.contains("hide") &&
        !phoneExist.classList.contains("hide") &&
        !existId.classList.contains("hide") &&
        !lessDepart.classList.contains("hide") &&
        !overDepart.classList.contains("hide")
    ) {
        let studName = name.value;
        let studPhone = phone.value;
        let studId = id.value;
        let studAddress = address.value;
        let studGender = gender.value;
        let studDepart = department.value;
        let studYear = year.value;
        let pass = JSON.parse(localStorage.getItem("studData"))[studNum].studPass;
        let studData = {
            studName: studName,
            studPhone: studPhone,
            studId: studId,
            studAddress: studAddress,
            studGender: studGender,
            studDepart: studDepart,
            studYear: studYear,
            studPass: pass,
        };

        if (localStorage.getItem("studData") != null) {            
            for (
              let i = 0;
              i < JSON.parse(localStorage.getItem("studData")).length;
              i++
            ) {
              
              if (
                JSON.parse(localStorage.getItem("studData"))[studNum].studId !=
                JSON.parse(localStorage.getItem("studData"))[i].studId
              ) {
                stud2.push(JSON.parse(localStorage.getItem("studData"))[i]);
              }
            }
        }
        stud2.push(studData);
        localStorage.setItem("studData", JSON.stringify(stud2));

        window.location.replace("../html/mainTeach.html");
    }
});


del.addEventListener("click" , () => {
    let stud2 = []
    for (
      let i = 0;
      i < JSON.parse(localStorage.getItem("studData")).length;
      i++
    ) {
      if (
        JSON.parse(localStorage.getItem("studData"))[studNum].studId !=
        JSON.parse(localStorage.getItem("studData"))[i].studId
      ) {
        stud2.push(JSON.parse(localStorage.getItem("studData"))[i]);
      }
    }
    localStorage.setItem("studData", JSON.stringify(stud2));
    window.location.replace("../html/mainTeach.html");
})

id.disabled = true
localStorage.removeItem("studNum");



