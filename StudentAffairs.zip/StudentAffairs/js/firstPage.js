let optOne = document.getElementById("optionOne");
let optTwo = document.getElementById("optionTwo");


optOne.addEventListener("click", () =>
  window.open("../html/loginTeach.html", "_self")
);
optTwo.addEventListener("click", () =>
  window.open("../html/loginStud.html", "_self")
);
