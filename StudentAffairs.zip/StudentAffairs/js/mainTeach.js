let land=document.getElementById("land")
let imgArr = [
  "../pictures/fc1v2.jpg",
  "../pictures/fc2v2.jpg",
  "../pictures/fc3v2.jpg",
  "../pictures/fc4v2.jpg",
  "../pictures/fc5v2.jpg",
  "../pictures/fc6v2.jpg",
  "../pictures/fc7.jpg",
  "../pictures/fc8v2.jpg",
];

setInterval(()=>{
    let num = Math.floor(Math.random() * imgArr.length);
    console.log(imgArr[num])
    land.style.backgroundImage = 'url('+imgArr[num]+')'
} , 4000)


function go(){
  window.location.replace("../html/firstPage.html")
}
