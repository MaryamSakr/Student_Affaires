let old = document.getElementById("old")
let newpass = document.getElementById("new");
let confirm = document.getElementById("confirm");
let submit = document.getElementById("submit")
let errorOld = document.getElementById("errorOld")
let errorNew = document.getElementById("errorNew");
let errorConfirm = document.getElementById("errorconfirm");



submit.addEventListener("click", () => {
    submit.disabled = true;
    passReg =
        /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (old.value !== JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studPass) {
        errorOld.classList.add("hide")
        errorNew.classList.remove("hide")
        errorConfirm.classList.remove("hide")
    }
    else if (!(newpass.value.match(passReg))) {
        errorOld.classList.remove("hide")
        errorNew.classList.add("hide")
        errorConfirm.classList.remove("hide")
    }
    else if (newpass.value !== confirm.value && newpass.value != "") {
        errorOld.classList.remove("hide");
        errorNew.classList.remove("hide");
        errorConfirm.classList.add("hide");

    }
    else {
        stud2 = []
        submit.disabled = false;
        errorOld.classList.remove("hide");
        errorNew.classList.remove("hide");
        errorConfirm.classList.remove("hide");
        if (localStorage.getItem("studData") != null) {
            for (
                let i = 0;
                i < JSON.parse(localStorage.getItem("studData")).length;
                i++
            ) {

                if (
                    localStorage.getItem("studNum") != i
                ) {
                    stud2.push(JSON.parse(localStorage.getItem("studData"))[i]);
                }
            }
        }
        let studData = {
            studName: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studName,
            studPhone: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studPhone,
            studId: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studId,
            studAddress: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studAddress,
            studGender: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studGender,
            studDepart: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studDepart,
            studYear: JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")].studYear,
            studPass: newpass.value,
        };

        stud2.push(studData);
        localStorage.setItem("studData", JSON.stringify(stud2));

        window.open("../html/loginStud.html", "_self")
    }
    submit.disabled = false;
})


