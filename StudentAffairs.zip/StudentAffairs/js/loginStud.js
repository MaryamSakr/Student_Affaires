let submit = document.getElementById("submit");
let id = document.getElementById("id");
let pass = document.getElementById("pass");
let errorPass = document.getElementById("errorPass");
let errorMail = document.getElementById("errorMail");
let flag = false;

id.addEventListener("blur", () => {
  let i = 0;
  for (; i < JSON.parse(localStorage.getItem("studData")).length; i++) {
    if (
      id.value ===
      JSON.parse(localStorage.getItem("studData"))[i].studId
    ) {
      submit.disabled = false;
      errorMail.classList.remove("hide");
      pass.addEventListener("blur", () => {
        if (
          JSON.parse(localStorage.getItem("studData"))[i].studPass ===
          pass.value
        ) {
          submit.disabled = false;
          flag = true;
          errorPass.classList.remove("hide");
          localStorage.setItem("studNum" , i)
          localStorage.removeItem("idValue")
          window.open("../html/mainStud.html", "_self");
        } else {
          submit.disabled = true;
          errorPass.classList.add("hide");
        }
      });
      break;
    } else {
      submit.disabled = true;
      errorMail.classList.add("hide");
    }
    if (flag) {
      submit.disabled = false;
      window.open("../html/mainStud.html", "_self");
    }
  }
  
});


