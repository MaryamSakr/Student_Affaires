let id = document.getElementById("id");
let search = document.getElementById("search");
let update = document.getElementById("update");
let errorId = document.getElementById("errorId");
let table = document.getElementById("data");
let found;

search.addEventListener("click", () => {
    idValue = id.value;
    let flag = false;
    
    for (
        let i = 0;
        i < JSON.parse(localStorage.getItem("studData")).length;
        i++
    ) {
        console.log(idValue);
        console.log(JSON.parse(localStorage.getItem("studData"))[i].studId);
        if (idValue === JSON.parse(localStorage.getItem("studData"))[i].studId) {
            found = i;
            flag = true;
            break;
        }
    }
    if (!flag) {
        errorId.classList.add("hide");
    } else {
        errorId.classList.remove("hide");
        table.classList.add("hide");
        let r = table.insertRow(1);
        let n1 = r.insertCell(0);
        let n2 = r.insertCell(1);
        let n3 = r.insertCell(2);
        let n4 = r.insertCell(3);
        let n5 = r.insertCell(4);
        let n6 = r.insertCell(5);
        let n7 = r.insertCell(6);
        n1.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studName
            }`;
        n2.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studId
            }`;
        n3.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studGender
            }`;
        n4.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studAddress
            }`;
        n5.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studPhone
            }`;
        n6.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studYear
            }`;
        if (
            JSON.parse(localStorage.getItem("studData"))[found].studDepart ==
            "--Select Department--"
        ) {
            n7.innerHTML = "None";
        } else {
            n7.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[found].studDepart
                }`;
        }
    }
});

update.addEventListener("click", () => {
    idValue = id.value;
    let flag = false;
    let found;
    for (
        let i = 0;
        i < JSON.parse(localStorage.getItem("studData")).length;
        i++
    ) {
        console.log(JSON.parse(localStorage.getItem("studData"))[i].studId);
        if (idValue === JSON.parse(localStorage.getItem("studData"))[i].studId) {
            found = i;
            localStorage.setItem("studNum", found);
            flag = true;
            break;
        }
    }
    if (!flag) {
        errorId.classList.add("hide");
    }else{
        table.classList.remove("hide");
        window.open("../html/updStud.html","_self")
    }
})
