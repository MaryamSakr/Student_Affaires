let name = document.getElementById("name");
let phone = document.getElementById("phone");
let mail = document.getElementById("email");
let address = document.getElementById("address");
let gender = document.getElementById("gender");
let department = document.getElementById("department");
let errorPhone = document.getElementById("errorPhone");
let phoneExist = document.getElementById("phoneExist");
let errorMail = document.getElementById("errorMail");
let mailExist = document.getElementById("mailExist");
let emptyError = document.getElementById("emptyError");
let sub = document.getElementById("submit");
let myForm = document.getElementById("form");
let teachers = [];



function generatepass() {
  let pass = "";
  let str =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz0123456789@#$&*";
  for (let i = 0; i <= 8; i++) {
    let char = Math.floor(Math.random() * str.length + 1);
    pass += str.charAt(char);
  }
  return pass;
}

myForm.addEventListener("click", () => {
  phone.addEventListener("blur", () => {
    phoneval = phone.value;
    phonereg = /^(01(1|2|5|0)\d*)/g;
    if (!(phoneval.match(phonereg) && phoneval.length == 11)) {
      errorPhone.classList.add("hide");
    } else {
      errorPhone.classList.remove("hide");
    }
    if (localStorage.getItem("teachersData") != null) {
      for (
        let i = 0;
        i < JSON.parse(localStorage.getItem("teachersData")).length;
        i++
      ) {
        if (
          phoneval ===
          JSON.parse(localStorage.getItem("teachersData"))[i].teachPhone
        ) {
          phoneExist.classList.add("hide");
          break;
        } else {
          phoneExist.classList.remove("hide");
        }
      }
    }
  });

  mail.addEventListener("blur", () => {
    mailval = mail.value;
    let mailre = /\w+(@){1}\w+\.{1}(com|org|net){1}/g;
    if (!mailval.match(mailre)) {
      errorMail.classList.add("hide");
    } else {
      errorMail.classList.remove("hide");
    }
    if (localStorage.getItem("teachersData") != null) {
      for (
        let i = 0;
        i < JSON.parse(localStorage.getItem("teachersData")).length;
        i++
      ) {
        if (
          mailval ===
          JSON.parse(localStorage.getItem("teachersData"))[i].teachMail
        ) {
          mailExist.classList.add("hide");
          break;
        } else {
          mailExist.classList.remove("hide");
        }
      }
    }
  });

  
});

sub.addEventListener("click" ,() => {
  if (
    name.value !== "" &&
    phone.value !== "" &&
    mail.value !== "" &&
    address.value !== "" &&
    gender.value !== "--Selcect Gender--" &&
    department.value !== "--Selcect Department--" &&
    !mailExist.classList.contains("hide") &&
    !phoneExist.classList.contains("hide")
  ) {
    let teachName = name.value;
    let teachPhone = phone.value;
    let teachmail = mail.value;
    let teachAddress = address.value;
    let teachGender = gender.value;
    let teachDepart = department.value;
    let pass = generatepass();
    let teacherData = {
      teachName: teachName,
      teachPhone: teachPhone,
      teachMail: teachmail,
      teachAddress: teachAddress,
      teachGender: teachGender,
      teachDepart: teachDepart,
      teachPass: pass,
    };
    if (localStorage.getItem("teachersData") != null) {
      teachers = JSON.parse(localStorage.getItem("teachersData"));
    }
    teachers.push(teacherData);
    localStorage.setItem("teachersData", JSON.stringify(teachers));

    window.open("../html/verifyPage.html", "_self");
  }
})




