let container = document.getElementById("container");
let change = document.getElementById("change")
console.log(
    JSON.parse(localStorage.getItem("studData"))[localStorage.getItem("studNum")]
        .studId
);
let name = JSON.parse(localStorage.getItem("studData"))[
    localStorage.getItem("studNum")
].studName;
let id = JSON.parse(localStorage.getItem("studData"))[
    localStorage.getItem("studNum")
].studId;
let phone = JSON.parse(localStorage.getItem("studData"))[
    JSON.parse(localStorage.getItem("studNum"))
].studPhone;
let address = JSON.parse(localStorage.getItem("studData"))[
    JSON.parse(localStorage.getItem("studNum"))
].studAddress;
let gender = JSON.parse(localStorage.getItem("studData"))[
    JSON.parse(localStorage.getItem("studNum"))
].studGender;
let year = JSON.parse(localStorage.getItem("studData"))[
    JSON.parse(localStorage.getItem("studNum"))
].studYear;
let depart = JSON.parse(localStorage.getItem("studData"))[
    JSON.parse(localStorage.getItem("studNum"))
].studDepart;
let data = [name, id, phone, address, gender, year, depart];
let des = ["Name", "Id", "Phone", "Address", "Gender", "Year", "Depart"];
for (let i = 5; i >=0; i--) {
    let item = document.createElement("div");
    if (i == 0 && data[i] == "--Select Department--") {
        item.innerHTML = des[i] + ": None";
    } else {
        item.innerHTML = des[i] + ": " + data[i];
    }
    container.prepend(item);

}

change.addEventListener("click" , () => {
    window.open("../html/changePass.html" , "_self")
})
