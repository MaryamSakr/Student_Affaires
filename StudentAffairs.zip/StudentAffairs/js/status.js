let table = document.getElementById("data");

for (
    let i = 0;
    i < JSON.parse(localStorage.getItem("studData")).length;
    i++
) {
    let r = table.insertRow(i+1);
    let n1 = r.insertCell(0);
    let n2 = r.insertCell(1);
    let n3 = r.insertCell(2);
    let n4 = r.insertCell(3);
    let n5 = r.insertCell(4);
    let n6 = r.insertCell(5);
    let n7 = r.insertCell(6);
    n1.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studName
        }`;
    n2.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studId
        }`;
    n3.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studGender
        }`;
    n4.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studAddress
        }`;
    n5.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studPhone
        }`;
    n6.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studYear
        }`;
    if (
        JSON.parse(localStorage.getItem("studData"))[i].studDepart ==
        "--Select Department--"
    ) {
        n7.innerHTML = "None";
    } else {
        n7.innerHTML = `${JSON.parse(localStorage.getItem("studData"))[i].studDepart
            }`;
    }
}
