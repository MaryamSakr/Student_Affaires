let id = document.getElementById("id");
let phone = document.getElementById("phone");
let name = document.getElementById("name");
let address = document.getElementById("address");
let gender = document.getElementById("gender");
let year = document.getElementById("year");
let department = document.getElementById("department");

let errorid = document.getElementById("errorId");
let errorPhone = document.getElementById("errorPhone");
let existId = document.getElementById("existId")
let phoneExist =document.getElementById("phoneExist")
let lessDepart = document.getElementById("lessDepart")
let overDepart = document.getElementById("overDepart")

let sub = document.getElementById("submit");
let myForm = document.getElementById("form");
let stud = [];


function resetForm() {
  name.value = "";
  id.value = "";
  phone.value = "";
  address.value = "";
  year.value = "--Select Year--";
  gender.value = "--Select Gender--";
  department.value = "--Select Department--";

  errorid.classList.remove("hide");
  errorPhone.classList.remove("hide");
  existId.classList.remove("hide");
  phoneExist.classList.remove("hide");
  lessDepart.classList.remove("hide");
  overDepart.classList.remove("hide");
}

function generatepass() {
  let pass = "";
  let str =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz0123456789@#$&*";
  for (let i = 0; i <= 8; i++) {
    let char = Math.floor(Math.random() * str.length + 1);
    pass += str.charAt(char);
  }
  return pass;
}

myForm.addEventListener("click", () => {
  

  id.addEventListener("blur", () => {
    idValue = id.value;

    if (idValue.length != 8 || isNaN(idValue)) {
      errorid.classList.add("hide");
    } else {
      errorid.classList.remove("hide");
    }
    if (localStorage.getItem("studData") != null) {
      for (
        let i = 0;
        i < JSON.parse(localStorage.getItem("studData")).length;
        i++
      ) {
        if (
          idValue ===
          JSON.parse(localStorage.getItem("studData"))[i].studId
        ) {
          existId.classList.add("hide");
          break;
        } else {
          existId.classList.remove("hide");
        }
      }
    }
  });

  phone.addEventListener("blur", () => {
    phoneval = phone.value;
    phonereg = /^(01(1|2|5|0)\d*)/g;
    if (!(phoneval.match(phonereg) && phoneval.length == 11)) {
      errorPhone.classList.add("hide");
    } else {
      errorPhone.classList.remove("hide");
    }
    if (localStorage.getItem("studData") != null) {
      for (
        let i = 0;
        i < JSON.parse(localStorage.getItem("studData")).length;
        i++
      ) {
        if (
          phoneval === JSON.parse(localStorage.getItem("studData"))[i].studPhone
        ) {
          phoneExist.classList.add("hide");
          break;
        } else {
          phoneExist.classList.remove("hide");
        }
      }
    }
  });

  department.addEventListener("blur" , () => {
    depValue=department.vlaue;
    if(department.value !== "--Select Department--"){
      overDepart.classList.remove("hide");
      if(year.value!=3 && year.value!=4){
        lessDepart.classList.add("hide")
      }
      else{
        lessDepart.classList.remove("hide")
      }
    }else{
      lessDepart.classList.remove("hide");
      if(year.value==3 && year.value==4){
        overDepart.classList.add("hide")
      }
      else{
        overDepart.classList.remove("hide")
      }
    }
  })

  year.addEventListener("click" , () =>{
    yearValue = year.value;
    if (
      year.value == 1 ||
      year.value == 2 ||
      year.value == "--Select Year--"
    ) {
      overDepart.classList.remove("hide");
      if (department.value !== "--Select Department--") {
        lessDepart.classList.add("hide");
      } else {
        lessDepart.classList.remove("hide");
      }
    } else {
      lessDepart.classList.remove("hide");
      if (department.value === "--Select Department--") {
        overDepart.classList.add("hide");
      } else {
        overDepart.classList.remove("hide");
      }
    }
  })

  
  
});


sub.addEventListener("click" , () => {
  if (
    name.value !== "" &&
    id.value !== "" &&
    phone.value !== "" &&
    address.value !== "" &&
    year.value !== "--Select Year--" &&
    gender.value !== "--Select Gender--" &&
    !errorid.classList.contains("hide") &&
    !errorPhone.classList.contains("hide") &&
    !phoneExist.classList.contains("hide") &&
    !existId.classList.contains("hide") &&
    !lessDepart.classList.contains("hide") &&
    !overDepart.classList.contains("hide")
  ) {
    let studName = name.value;
    let studPhone = phone.value;
    let studId = id.value;
    let studAddress = address.value;
    let studGender = gender.value;
    let studDepart = department.value;
    let studYear = year.value;
    let pass = generatepass();
    let studData = {
      studName: studName,
      studPhone: studPhone,
      studId: studId,
      studAddress: studAddress,
      studGender: studGender,
      studDepart: studDepart,
      studYear: studYear,
      studPass: pass,
    };
    if (localStorage.getItem("studData") != null) {
      stud = JSON.parse(localStorage.getItem("studData"));
    }
    stud.push(studData);
    localStorage.setItem("studData", JSON.stringify(stud));

    window.open("../html/mainTeach.html", "_self");
  }
})

window.addEventListener("pageshow", (event) => {
    resetForm();

});



// localStorage.removeItem("studData")