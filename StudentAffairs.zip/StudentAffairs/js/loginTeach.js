let sub = document.getElementById("submit");
let user = document.getElementById("user");
let pass = document.getElementById("pass");
let errorPass = document.getElementById("errorPass");
let errorMail = document.getElementById("errorMail");
let flag = false;

user.addEventListener("blur", () => {
  let i = 0;
  for (; i < JSON.parse(localStorage.getItem("teachersData")).length; i++) {
    if (
      user.value ===
      JSON.parse(localStorage.getItem("teachersData"))[i].teachMail
    ) {
      sub.disabled = false;
      errorMail.classList.remove("hide");

      pass.addEventListener("blur", () => {
        if (
          JSON.parse(localStorage.getItem("teachersData"))[i].teachPass ===
          pass.value
        ) {
          sub.disabled = false;
          flag = true;
          errorPass.classList.remove("hide");
          window.open("../html/mainTeach.html", "_self");
        } else {
          sub.disabled = true;
          errorPass.classList.add("hide");
        }
      });
      break;
    } else {
      sub.disabled = true;
      errorMail.classList.add("hide");
    }
    if (flag) {
      sub.disabled = false;

      window.open("../html/mainTeach.html", "_self");
    }
  }
});
